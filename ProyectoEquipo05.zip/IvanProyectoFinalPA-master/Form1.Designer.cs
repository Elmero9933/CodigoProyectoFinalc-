﻿namespace programacionAvanzadaPF
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnPiso3 = new System.Windows.Forms.Button();
            this.btnPiso2 = new System.Windows.Forms.Button();
            this.btnPiso1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblObstaculo = new System.Windows.Forms.Label();
            this.lblGas = new System.Windows.Forms.Label();
            this.lblPeso = new System.Windows.Forms.Label();
            this.lblPiso = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnPiso3
            // 
            this.btnPiso3.BackColor = System.Drawing.Color.PaleGreen;
            this.btnPiso3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPiso3.Location = new System.Drawing.Point(332, 134);
            this.btnPiso3.Name = "btnPiso3";
            this.btnPiso3.Size = new System.Drawing.Size(100, 38);
            this.btnPiso3.TabIndex = 39;
            this.btnPiso3.Text = "Piso 3";
            this.btnPiso3.UseVisualStyleBackColor = false;
            this.btnPiso3.Click += new System.EventHandler(this.btnPiso3_Click);
            // 
            // btnPiso2
            // 
            this.btnPiso2.BackColor = System.Drawing.Color.PaleGreen;
            this.btnPiso2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPiso2.Location = new System.Drawing.Point(226, 134);
            this.btnPiso2.Name = "btnPiso2";
            this.btnPiso2.Size = new System.Drawing.Size(100, 38);
            this.btnPiso2.TabIndex = 38;
            this.btnPiso2.Text = "Piso 2";
            this.btnPiso2.UseVisualStyleBackColor = false;
            this.btnPiso2.Click += new System.EventHandler(this.btnPiso2_Click);
            // 
            // btnPiso1
            // 
            this.btnPiso1.BackColor = System.Drawing.Color.PaleGreen;
            this.btnPiso1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPiso1.Location = new System.Drawing.Point(120, 134);
            this.btnPiso1.Name = "btnPiso1";
            this.btnPiso1.Size = new System.Drawing.Size(100, 38);
            this.btnPiso1.TabIndex = 37;
            this.btnPiso1.Text = "Piso 1";
            this.btnPiso1.UseVisualStyleBackColor = false;
            this.btnPiso1.Click += new System.EventHandler(this.btnPiso1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(390, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(144, 29);
            this.label1.TabIndex = 36;
            this.label1.Text = "Obstaculo:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(276, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(70, 29);
            this.label2.TabIndex = 35;
            this.label2.Text = "Gas:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(151, 37);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(83, 29);
            this.label3.TabIndex = 34;
            this.label3.Text = "Peso:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(35, 36);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 29);
            this.label4.TabIndex = 33;
            this.label4.Text = "Piso:";
            // 
            // lblObstaculo
            // 
            this.lblObstaculo.AutoSize = true;
            this.lblObstaculo.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblObstaculo.Location = new System.Drawing.Point(390, 73);
            this.lblObstaculo.Name = "lblObstaculo";
            this.lblObstaculo.Size = new System.Drawing.Size(153, 29);
            this.lblObstaculo.TabIndex = 32;
            this.lblObstaculo.Text = "lblObstaculo";
            // 
            // lblGas
            // 
            this.lblGas.AutoSize = true;
            this.lblGas.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblGas.Location = new System.Drawing.Point(276, 73);
            this.lblGas.Name = "lblGas";
            this.lblGas.Size = new System.Drawing.Size(85, 29);
            this.lblGas.TabIndex = 31;
            this.lblGas.Text = "lblGas";
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeso.Location = new System.Drawing.Point(151, 73);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(97, 29);
            this.lblPeso.TabIndex = 30;
            this.lblPeso.Text = "lblPeso";
            // 
            // lblPiso
            // 
            this.lblPiso.AutoSize = true;
            this.lblPiso.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPiso.Location = new System.Drawing.Point(35, 72);
            this.lblPiso.Name = "lblPiso";
            this.lblPiso.Size = new System.Drawing.Size(89, 29);
            this.lblPiso.TabIndex = 29;
            this.lblPiso.Text = "lblPiso";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Coral;
            this.ClientSize = new System.Drawing.Size(585, 206);
            this.Controls.Add(this.btnPiso3);
            this.Controls.Add(this.btnPiso2);
            this.Controls.Add(this.btnPiso1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblObstaculo);
            this.Controls.Add(this.lblGas);
            this.Controls.Add(this.lblPeso);
            this.Controls.Add(this.lblPiso);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button btnPiso3;
        private System.Windows.Forms.Button btnPiso2;
        private System.Windows.Forms.Button btnPiso1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblObstaculo;
        private System.Windows.Forms.Label lblGas;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.Label lblPiso;
    }
}

