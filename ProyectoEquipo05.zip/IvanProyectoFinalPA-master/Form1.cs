﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO.Ports;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using Mysqlx.Crud;

namespace programacionAvanzadaPF
{
    public partial class Form1 : Form
    {
        private SerialPort SP;

        // Variables para almacenar datos del elevador
        private int pisoActual = 1;
        private float pesoActual = 0;
        private bool limiteExcedido = false;
        private bool gasDetectado = false;
        private bool obstaculoDetectado = false;

        public Form1()
        {
            InitializeComponent();
            InitializeSP();
        }

        private void InitializeSP()
        {
            try
            {
                SP = new SerialPort("COM4", 9600);
                SP.DataReceived += SP_DataReceived;
                SP.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error al abrir puerto serial: {ex.Message}");
                // Environment.Exit(1);
            }
        }

        private void SP_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            try
            {
                if (!IsHandleCreated || IsDisposed) return;
                string data = SP.ReadLine();

                Invoke(new Action(() =>
                {
                    try
                    {
                        ParseMostrarDatos(data);
                    }
                    catch
                    {
                        // Sin mensaje
                    }
                }));
            }
            catch
            {
                // Sin mensajes
            }
        }

        private void ParseMostrarDatos(string data)
        {
            string[] lines = data.Split('\n');
            foreach (string line in lines)
            {
                if (line.StartsWith("PISO:"))
                {
                    pisoActual = int.Parse(line.Substring(5));
                    lblPiso.Text = pisoActual.ToString();
                }
                else if (line.StartsWith("PESO:"))
                {
                    pesoActual = float.Parse(line.Substring(5));
                    limiteExcedido = pesoActual > 100;
                    if (limiteExcedido)
                    {
                        lblPeso.Text = "Exceso";
                    }
                    else
                    {
                        lblPeso.Text = pesoActual.ToString("0.00");
                    }
                }
                else if (line.StartsWith("GAS:"))
                {
                    gasDetectado = line.Substring(4).Trim() == "DETECTADO";
                    lblGas.Text = gasDetectado ? "Sí" : "No";
                }
                else if (line.StartsWith("OBSTACULO:"))
                {
                    obstaculoDetectado = line.Substring(10).Trim() == "DETECTADO";
                    lblObstaculo.Text = obstaculoDetectado ? "Sí" : "No";
                }
            }
        }

        private void btnPiso1_Click(object sender, EventArgs e)
        {
            SP.WriteLine("PISO:1\n");
        }

        private void btnPiso2_Click(object sender, EventArgs e)
        {
            SP.WriteLine("PISO:2\n");
        }

        private void btnPiso3_Click(object sender, EventArgs e)
        {
            SP.WriteLine("PISO:3\n");
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            SP.Close();
        }
    }
}
